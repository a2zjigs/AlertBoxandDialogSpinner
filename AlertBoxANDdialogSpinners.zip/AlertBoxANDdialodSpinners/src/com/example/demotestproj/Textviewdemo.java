package com.example.demotestproj;

import android.app.Activity;
import android.os.Bundle;

public class Textviewdemo extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newact);
	}

}
