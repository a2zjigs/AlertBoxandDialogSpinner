package com.example.demotestproj;

import java.util.ArrayList;

import android.R.string;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class MainActivity extends Activity {

	public final String nam[] = { "TextView", "EditText", "ImageView",
			"Spinner", "All", "Alert", "TabLayout" };
	Intent intent;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ArrayList<String> categoryname = new ArrayList<String>();
		for (int i = 0; i < nam.length; i++) {
			categoryname.add(nam[i]);
		}

		ListView lv = (ListView) findViewById(R.id.listview);
		lv.setAdapter(new AdapterList(this, categoryname));
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> paramAdapterView,
					View paramView, int paramInt, long paramLong) {
				if (paramInt == 0) {
					intent = new Intent(MainActivity.this, Textviewdemo.class);
					startActivity(intent);
				} else if (paramInt == 1) {
					intent = new Intent(MainActivity.this, EditViewDemo.class);
					startActivity(intent);

				} else if (paramInt == 2) {
					intent = new Intent(MainActivity.this, Imageviewdemo.class);
					startActivity(intent);

				} else if (paramInt == 3) {
					intent = new Intent(MainActivity.this, Spinnerdemo.class);
					startActivity(intent);

				} else if (paramInt == 4) {
					intent = new Intent(MainActivity.this,

					DemowithAll.class);
					startActivity(intent);

				} else if (paramInt == 5) {
					intent = new Intent(MainActivity.this,

					AllAlertBoxExample.class);
					startActivity(intent);

				} else if (paramInt == 6) {
					intent = new Intent(MainActivity.this,

					TabAct.class);
					startActivity(intent);

				}
				// TODO Auto-generated method stub

			}
		});
	}

}
