package com.example.demotestproj;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class AllAlertBoxExample extends Activity implements OnClickListener {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		findViewById(R.id.button1).setOnClickListener(this);
		findViewById(R.id.button2).setOnClickListener(this);
		findViewById(R.id.button3).setOnClickListener(this);
		findViewById(R.id.button4).setOnClickListener(this);
		findViewById(R.id.button5).setOnClickListener(this);
	}


	private void SimpleAlert() {
		Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Simple Alert");
		builder.setMessage("This is simple alert box");
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private String[] selectFruit = { "Apple", "Banana", "Papaya", "Pine-Apple",
			"Guauva" };

	private void SingleChoice() {
		Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Single Choice");
		builder.setItems(selectFruit, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast.makeText(AllAlertBoxExample.this,
						selectFruit[which] + "  Selected", Toast.LENGTH_LONG)
						.show();
				dialog.dismiss();
			}
		});
		builder.setNegativeButton("cancel",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private void SingleChoiceWithRadioButton() {
		Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Single Choice With Radio button");
		builder.setSingleChoiceItems(selectFruit, -1,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						Toast.makeText(AllAlertBoxExample.this,
								selectFruit[which] + "  Selected",
								Toast.LENGTH_LONG).show();
						dialog.dismiss();
					}
				});
		builder.setNegativeButton("cancel",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private boolean[] selectVal = { false, false, false, false, false };
	private String selectetdVal = "";

	private void MultipleChoiceAlertBox() {
		Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Multiple Choice");
		builder.setMultiChoiceItems(selectFruit, selectVal,
				new DialogInterface.OnMultiChoiceClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which,
							boolean isChecked) {
						selectVal[which] = isChecked;
					}
				});
		builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				for (int i = 0; i < selectFruit.length; i++) {
					if (selectVal[i]) {
						selectetdVal += "+" + selectFruit[i];
					}
				}
				Toast.makeText(AllAlertBoxExample.this, selectetdVal,
						Toast.LENGTH_LONG).show();

			}
		});
		builder.setNegativeButton("cancel",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private void AlertUsingAdapter() {
		Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Adapter Alert");
		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1);
		for (int i = 0; i < selectVal.length; i++) {
			arrayAdapter.add(selectFruit[i]);
		}
		builder.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast.makeText(AllAlertBoxExample.this, selectFruit[which],
						Toast.LENGTH_LONG).show();
			}
		});
		builder.setPositiveButton("Cancel",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button1:
			SimpleAlert();
			break;
		case R.id.button2:
			SingleChoice();
			break;
		case R.id.button3:
			SingleChoiceWithRadioButton();
			break;
		case R.id.button4:
			MultipleChoiceAlertBox();
			break;
		case R.id.button5:
			AlertUsingAdapter();
			break;
		}

	}
}
